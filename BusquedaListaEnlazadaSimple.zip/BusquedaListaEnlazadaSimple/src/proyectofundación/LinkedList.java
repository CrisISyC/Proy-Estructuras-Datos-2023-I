
package proyectofundación;

import java.io.FileReader;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class LinkedList{
    public static void main(String[] args)throws Exception{
       
        long startTime = System.nanoTime();
       
        JSONParser parser = new JSONParser();
        FileReader reader = new FileReader("Ubicacion del archivo");
        Object obj = parser.parse(reader);
        JSONObject pJsonObj = (JSONObject)obj;
        JSONArray array = (JSONArray) pJsonObj.get("Usuarios");
       

        LinkedList_ listaPeluditos = new LinkedList_();
       
        for (int i = 0; i < array.size(); i++) {
            JSONObject usuario = (JSONObject)array.get(i);
            Long myLong = (Long) usuario.get("id");
            int id = myLong.intValue();
            myLong = (Long) usuario.get("edad");
            int edad = myLong.intValue();
            listaPeluditos.insert(edad, id);          
        }
       
        long endTime = System.nanoTime();
        long duration = (endTime - startTime); // en nanosegundos
        double seconds = (double)duration / 1_000_000_000.0; // en segundos
        System.out.println("El tiempo de ejecucion es de " + seconds + " segundos.");

    }

}

class Node {
   
    Node next;
    int id;
    int edad;
   
    public Node(int edad, int id) {
        this.edad = edad;
        this.id = id;
        next = null;
    }

    public Node getNext() {
        return next;
    }
    public void setNext(Node next) {
        this.next = next;
    }

    public int getEdad() {
        return edad;
    }
    public void setEdad(int edad) {
        this.edad = edad;
    }   

    public int getID() {
        return id;
    }
    public void setID(int id) {
        this.id= id;
    }  


}

class LinkedList_ {
    
    Node head;
    Node queue;
       
    public void find(int edad) {
        int counter = 0;
        Node start = head;
        System.out.println("Edad   ID");
        while (start != null) {
            if(edad == start.getEdad()){
                System.out.println(" "+ start.getEdad()+ "     "+ start.getID());
                counter++;
            }
            start = start.next;

        }
        System.out.println("El resultado de la busqueda fueron " + counter +  " peludos" );
    }

    public void update(int id, int edad) {
        Node start = head;
        while (start != null) {
            if(id == start.getID()){
                start.setEdad(edad);
                break;
            }
            start = start.next;
            if (start == null){
                System.out.println("No se encontro ese ID");
            }
        }
        if(start != null){
            System.out.println("se ha cambiado la edad del perrito "+ start.getID());
        }
    }    
    
    public void delete(int id) {
        Node start = head;
        if (head == null) {
            System.out.println("La lista esta vacia no se puede eliminar nada");
            return;
        }
        if (head.id == id) {
            head = head.next;
            return;
        }
        while (start.next != null) {
            if (start.next.id == id) {
                start.next = start.next.next;
                System.out.println("el perrito "+ id + " ha sido eliminado");
                return;
            }
            start = start.next;
        }
}

    public void printAll() {
        int counter = 0;
        Node start = head;
        System.out.println("Edad   ID");
        while (start != null) {
            System.out.println(" "+ start.getEdad()+ "     "+ start.getID());
            counter++;
            
            start = start.next;
        }
        System.out.println("hay " + counter + " peluditos");
    }
    
    public void insert(int edad, int id) {
        Node newNode = new Node(edad, id);
        if (head == null) {
            head = newNode;
            queue = head;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
            queue = temp.next;
           
        }
    }   
}