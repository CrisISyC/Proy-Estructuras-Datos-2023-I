package projectdatastructures_avl;


import java.io.FileReader;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class AVL {
    
    public static void main(String[] args)throws Exception {
        
        
        JSONParser parser = new JSONParser();
        FileReader reader = new FileReader("C:\\Users\\krist\\Desktop\\Cristian\\Ingenieria\\Data Structures\\Project Prototype\\Deliverable I\\Code\\JSON2\\ID en orden\\10millones.json");
        Object obj = parser.parse(reader);
        JSONObject pJsonObj = (JSONObject)obj;
        JSONArray array = (JSONArray) pJsonObj.get("Usuarios");
        
        AVLTree myAVL = new AVLTree();
      

        long startTime = System.nanoTime();
        for (int i = 0; i < 100000; i++) {
            JSONObject usuario = (JSONObject)array.get(i);
            Long myLong = (Long) usuario.get("id");
            int id = myLong.intValue();
            myAVL.insert(id);          
        }
        
        long endTime = System.nanoTime();
        long duration = (endTime - startTime); // en nanosegundos
        double seconds = (double)duration / 1_000_000_000.0; // en segundos
        System.out.println("El tiempo de inserción es de " + seconds + " segundos.");
        
        myAVL.delete(10);
        myAVL.printInOrder();
        
        
        myAVL.search(63239);
        
        
        long startTimeD = System.nanoTime();

        long endTimeD = System.nanoTime();
        long durationD = (endTimeD - startTimeD); // en nanosegundos
        double secondsD = (double)durationD / 1_000_000_000.0; // en segundos
        System.out.println("El tiempo de borrado es de " + secondsD + " segundos.");

        
        System.out.println("-----------------------------------");
        
    }
}

class AVLTree{

    AVLNode root = null;

    class AVLNode {
        String data;
        int id;
        int edad;
        int height;
        AVLNode childLeft;
        AVLNode childRight;

        public AVLNode(int id) {
            this.id = id;
            this.height = 1;
            this.childLeft = null;
            this.childRight = null;
        }

        public int getID() {
            return id;
        }
        public void setID(int id) {
            this.id= id;
        }  

        public int getHeight(){
            return height;
        }
        public void setHeight(int height){
            this.height = height;
        }
        
        public AVLNode getChildLeft() {
            return childLeft;
        }
        public void setChildLeft(AVLNode childLeft) {
            this.childLeft = childLeft;
        }

        public AVLNode getChildRight() {
            return childRight;
        }
        public void setChildRight(AVLNode childRight) {
            this.childRight = childRight;
        }
    }

    // Altura del nodo
    public int heightNode(AVLNode node) {
        if (node == null) {
            return 0;
        }
        return node.height;
    }

    // Rotacion hacia la derecha
    public AVLNode rightRotate(AVLNode y) {
        AVLNode x = y.childLeft;
        AVLNode temp = x.childRight;

        x.childRight = y;
        y.childLeft = temp;

        // Math.max devuelve el mayor entre (a,b)
        y.height = Math.max(heightNode(y.childLeft), heightNode(y.childRight)) + 1;
        x.height = Math.max(heightNode(x.childLeft), heightNode(x.childRight)) + 1;

        return x;
    }

    // Rotación hacia la izquierda
    public AVLNode leftRotate(AVLNode x) {
        AVLNode y = x.childRight;
        AVLNode temp = y.childLeft;

        y.childLeft = x;
        x.childRight = temp;

        x.height = Math.max(heightNode(x.childLeft), heightNode(x.childRight)) + 1;
        y.height = Math.max(heightNode(y.childLeft), heightNode(y.childRight)) + 1;

        return y;
    }

    //Comparar las alturas de los nodos para ver si estan o no balanceados
    public int balance(AVLNode node) {
        if (node == null) {
            return 0;
        }
        return heightNode(node.childLeft) - heightNode(node.childRight);
    }

    public void insert(int id) {
        root = insert(root,id);
    }
    public AVLNode insert(AVLNode node,int id) {
        
        if (node == null) {
            return new AVLNode(id);
        }

        if (id < node.id) {
            node.childLeft = insert(node.childLeft,id);
        } else if (id > node.id) {
            node.childRight = insert(node.childRight, id);
        } else {
            // El nodo con el mismo id ya existe, no se añade de nuevo
            return node;
        }

        node.height = 1 + Math.max(heightNode(node.childLeft), heightNode(node.childRight));
        int balance = balance(node);

        // Caso izquierda-izquierda
        if (balance > 1 && id < node.childLeft.getID()) {
            return rightRotate(node);
        }

        // Caso derecha-derecha
        if (balance < -1 && id > node.childRight.getID()) {
            return leftRotate(node);
        }

        // Caso izquierda-derecha
        if (balance > 1 && id > node.childLeft.getID()) {
            node.childLeft = leftRotate(node.childLeft);
            return rightRotate(node);
        }

        // Caso derecha-izquierda
        if (balance < -1 && id < node.childRight.getID()) {
            node.childRight = rightRotate(node.childRight);
            return leftRotate(node);
        }

        return node;
    }
 
    public void search(int id) {
        searchNode_(root, id);
    }  
    public AVLNode searchNode_(AVLNode node, int value) {
        
        long startTime = System.nanoTime();
        
        if (node == null) {
            return node;
        }

        if (node.id == value) {
            System.out.println("Nodo encontrado");
            System.out.println("ID: " + node.id);
            System.out.println("EDAD: " + node.edad);
            System.out.println("NOMBRE: " + node.data);
            
            long endTime = System.nanoTime();
            long duration = (endTime - startTime); // en nanosegundos
            double seconds = (double)duration / 1_000_000_000.0; // en segundos
            System.out.println("El tiempo de busqueda es de " + seconds + " segundos.");            
            return node;
        }

        if (value < node.id) {
            return searchNode_(node.childLeft, value);
        } else {
            return searchNode_(node.childRight, value);
        }
}
    
    public void update(int id, String nombre) {
        updateNode(root, id, nombre);
    }      
    public AVLNode updateNode(AVLNode node, int id, String nombre) {
    if (node == null) {
        return node;
    }

    if (node.id == id) {
        
        
        System.out.println("Nodo encontrado");
        System.out.println("ID: " + node.id);
        System.out.println("EDAD: " + node.edad);
        System.out.println("NOMBRE: " + node.data);
        
        System.out.println("Nodo actualizado");
        
        node.data = nombre;
        System.out.println("ID: " + node.id);
        System.out.println("EDAD: " + node.edad);
        System.out.println("NOMBRE: " + node.data);        
        
        return node;
    }

    if (id < node.id) {
        return updateNode(node.childLeft, id,nombre);
    } else {
        return updateNode(node.childRight, id,nombre);
    }
}    
    
    public void delete(int id) {
        deleteNode(root, id);
    }
    public AVLNode deleteNode(AVLNode node, int id) {
        
        if (node == null) {
            return node;
        }

        if (id < node.id) {
            node.childLeft = deleteNode(node.childLeft, id);
        } else if (id > node.id) {
            node.childRight = deleteNode(node.childRight, id);
        } else {
            // El nodo actual es el nodo que deseamos eliminar

            // Caso 1: Nodo con un solo hijo o sin hijos
            if (node.childLeft == null || node.childRight == null) {
                AVLNode child;
                if (node.childLeft != null) {
                    child = node.childLeft;
                } else {
                    child = node.childRight;
                }

                // Si no hay hijos, simplemente eliminamos el nodo
                if (child == null) {
                    node = null;
                } else { // Si hay un solo hijo, reemplazamos el nodo por el hijo
                    node = child;
                }
            } else {
                // Caso 2: Nodo con dos hijos
                // Encontramos el sucesor inorden (nodo más pequeño en el subárbol derecho)
                AVLNode sucesor = findSuccessor(node.childRight);

                // Copiamos los datos del sucesor al nodo actual
                node.data = sucesor.data;
                node.id = sucesor.id;
                node.edad = sucesor.edad;

                // Eliminamos el sucesor inorden recursivamente
                node.childRight = deleteNode(node.childRight, sucesor.id);
            }
        }

        // Si el árbol tenía solo un nodo, retornamos
        if (node == null) {
            return node;
        }

        // Actualizamos la altura del nodo actual
        node.height = Math.max(heightNode(node.childLeft), heightNode(node.childRight)) + 1;

        // Verificamos si el nodo actual está desbalanceado
        int balance = balance(node);

        // Realizamos las rotaciones necesarias según el caso de desbalance
        if (balance > 1 && balance(node.childLeft) >= 0) {
            return rightRotate(node);
        }

        if (balance > 1 && balance(node.childLeft) < 0) {
            node.childLeft = leftRotate(node.childLeft);
            return rightRotate(node);
        }

        if (balance < -1 && balance(node.childRight) <= 0) {
            return leftRotate(node);
        }

        if (balance < -1 && balance(node.childRight) > 0) {
            node.childRight = rightRotate(node.childRight);
            return leftRotate(node);
        }
       
        
        return node;
    }  
    public AVLNode findSuccessor(AVLNode nodo) {
        AVLNode start = nodo;
        while (start.childLeft != null) {
            start = start.childLeft;
        }
        return start;
    }    
    
    // Imprimir en orden a partir del nombre
    public void printInOrder() {
        System.out.printf("%-5s\n", "ID");
        printInOrder(root);
    }
    public void printInOrder(AVLNode node) {
        if (node != null) {
            printInOrder(node.childLeft);
          
            System.out.printf("%-5d\n", node.getID());               
           
            printInOrder(node.childRight);
        }
    }    
    
    // Imprime el camino desde el nodo a hasta el nodo b
    public void range(int a, int b) {
        range_(root, a, b);
    }
    public AVLNode range_(AVLNode node, int a, int b) {
        if (node == null) {
            return null;
        }

        AVLNode result = null;

        if (node.id > a) {
            result = range_(node.childLeft, a, b);
        }

        if (node.id >= a && node.id <= b) {
            System.out.println(node.id);
        }

        if (node.id < b) {
            result = range_(node.childRight, a, b);
        }

        return result;
    }

    //Buscar el camino más corto entre dos nodos
    public AVLNode searchNode(AVLNode node, int value) {
    if (node == null) {
        return node;
    }
    if (value < node.id) {
        return searchNode(node.childLeft, value);
    } else {
        return searchNode(node.childRight, value);
    }
}
    public AVLNode findLowestAncestor(AVLNode root, AVLNode x, AVLNode y) {
        if (root == null || x == null || y == null) {
            return null;
        }
        if (root == x|| root == y) {
            return root;
        }
    
        AVLNode leftAncestor = findLowestAncestor(root.childLeft, x, y);
        AVLNode rightAncestor = findLowestAncestor(root.childRight, x, y);
    
        if (leftAncestor != null && rightAncestor != null) {
            return root; // X y Y esten en diferentes subarboles
        }
    
        if (leftAncestor != null) {
            return leftAncestor;
        } else {
            return rightAncestor;
        }
    }
    public int findPathLength(AVLNode root, AVLNode node) {
        if (root == null) {
            return 0;
        }
    
        if (root == node) {
            return 1;
        }
    
        int leftPathLength = findPathLength(root.childLeft, node);
        int rightPathLength = findPathLength(root.childRight, node);
    
        if (leftPathLength > 0) {
            return leftPathLength + 1;
        } else if (rightPathLength > 0) {
            return rightPathLength + 1;
        } else {
            return 0;
        }
    }
    public void rangeSearchShortestPath(int x, int y) {
        AVLNode nodeX = searchNode(root, x);
        AVLNode nodeY = searchNode(root, y);
    
        if (nodeX == null || nodeY == null) {
            System.out.println("Alguno de los nodos no existe en el arbol");
        }
    
        AVLNode ancestorNode = findLowestAncestor(root, nodeX, nodeY);
    
        int pathNodeX = findPathLength(ancestorNode, nodeX);
        int pathNodeY = findPathLength(ancestorNode, nodeY);
        
        int solution = pathNodeX + pathNodeY - 1;

        System.out.print(solution);
    }   
    
    
}
    
    
